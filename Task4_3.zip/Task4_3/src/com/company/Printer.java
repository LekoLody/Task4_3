package com.company;

public class Printer {
    String queue = "";
    String text;
    String name;
    int count = 0;
    int pendingCount = 0;
    int totalCount = 0;

    public void append(String text){
        this.text = text;
        queue = queue + "\n" + text + "\n";
        pendingCount ++;
    }

    public void append(String text, String name){
        this.text = text;
        this.name = name;
        queue = queue + "\n" + text + "\n" + name + "\n";
        pendingCount ++;
    }

    public void append(String text, String name, int count){
        this.text = text;
        this.name = name;
        this.count = count;
        pendingCount = pendingCount + count;
        queue = queue + "\n" + text + "\n" + name + "\n" + count + "\n";
    }

    public void print(){
        System.out.println(queue);
        clear();
    }

    public void clear(){
        queue = "";
    }

    public int getPendingPagesCount(){
        System.out.println("Pages pending: " + pendingCount);
        return pendingCount;
    }

    public int getTotalCount(){
        totalCount = totalCount + pendingCount;
        System.out.println("Total pages: " + totalCount);
        return totalCount;
    }
}
